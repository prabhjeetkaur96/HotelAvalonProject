package com.example.jeetp.hotelavalon;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NewBookingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    EditText edtNights;
    TextView txtChkOut, txtChkIn, txtPrice;
    Spinner spnAdults, spnChildren, spnRooms;
    Button btnSave;
    String[] adult = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"};
    String[] children = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"};
    String[] rooms = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"};

    String selectedChild, selectedAdult, selectedRooms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_booking);


        edtNights = findViewById(R.id.edtNights);

        txtPrice = findViewById(R.id.txtPrice);

        txtChkIn = findViewById(R.id.txtChkIn);
        txtChkIn.setOnClickListener(this);

        txtChkOut = findViewById(R.id.txtChkOut);
        txtChkOut.setOnClickListener(this);

        btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(this);


        spnAdults = findViewById(R.id.spnAdults);
        ArrayAdapter lotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, adult);
        spnAdults.setAdapter(lotAdapter);
        spnAdults.setOnItemSelectedListener(this);

        spnChildren = findViewById(R.id.spnChildren);
        ArrayAdapter spotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, children);
        spnChildren.setAdapter(spotAdapter);
        spnChildren.setOnItemSelectedListener(this);

        spnRooms = findViewById(R.id.spnRooms);
        ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms);
        spnRooms.setAdapter(paymentAdapter);
        spnRooms.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {


        if (view.getId() == btnSave.getId()) {
            SharedPreferences sp = getSharedPreferences("com.example.jeetp.hotelavalon.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("Check In Date", txtChkIn.getText().toString());
            edit.putString("Check Out Date", txtChkOut.getText().toString());
            edit.putString("Rooms", selectedRooms);
            edit.putString("Adult", selectedAdult);
            edit.putString("Children", selectedChild);
            edit.putString("Nights", edtNights.getText().toString());
            edit.putInt("Price",
                    Integer.parseInt(txtPrice.getText().toString().substring(1)));

            edit.commit();

        }
           else if(view.getId() == txtChkIn.getId()){
                Calendar calendar = Calendar.getInstance();
                DatePickerDialog.OnDateSetListener datePickerListener =null;
                new DatePickerDialog(this, datePickerListener,
                        calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        }
        DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                String date = String.valueOf(month+1) + "/" + String.valueOf(day) + "/" + String.valueOf(year);
                txtChkIn.setText(date);
            }
        };





    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if (adapterView.getId() == spnAdults.getId()) {
            selectedAdult = adult[position];
        } else if (adapterView.getId() == spnChildren.getId()) {
            selectedChild = children[position];
        } else if (adapterView.getId() == spnRooms.getId()) {
            selectedRooms = rooms[position];}
}

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
